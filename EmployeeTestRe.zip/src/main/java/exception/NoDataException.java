package exception;

public class NoDataException extends Exception{

}
